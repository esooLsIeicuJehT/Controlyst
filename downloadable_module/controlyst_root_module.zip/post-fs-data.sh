#!/system/bin/sh
chmod 666 /dev/uinput 2>/dev/null
