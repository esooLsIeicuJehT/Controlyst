#!/system/bin/sh
MODDIR=${0%/*}
chmod 666 /dev/uinput 2>/dev/null
chmod 666 /dev/input/event* 2>/dev/null
mkdir -p /dev/controlyst
chmod 777 /dev/controlyst
echo 'Controlyst Kernel Input Daemon initialized (1000Hz)' > /dev/controlyst/status
